package main.itemtypes;

import main.Item;

public class Transistor extends Item {

    @Override
    public String GetName() {
        return "Tranzisztor";
    }
}
